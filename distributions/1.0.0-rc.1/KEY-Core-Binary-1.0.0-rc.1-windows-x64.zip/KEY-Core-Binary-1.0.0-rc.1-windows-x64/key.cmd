@echo off
setlocal DisableDelayedExpansion
for %%C in (build run check test fmt rebuild generate version help --help --version) do if /I "%~1"=="%%C" goto native
if "%~1"=="" goto usage
if "%~2"=="" goto usage
if not "%~3"=="" goto usage
set "KEYC=%~dp0bin\keyc.exe"
set "INPUT=%~f1"
set "OUTPUT=%~f2"
if /I "%INPUT%"=="%OUTPUT%" (
  echo Input and output must be different files. 1>&2
  exit /b 2
)
if not exist "%INPUT%" (
  echo Source file not found: "%INPUT%" 1>&2
  exit /b 2
)
set "TEMP_OUT=%OUTPUT%.key-tmp-%RANDOM%-%RANDOM%"
pushd "%~dp1" || exit /b 2
"%KEYC%" < "%INPUT%" > "%TEMP_OUT%"
set "RC=%ERRORLEVEL%"
popd
if not "%RC%"=="0" goto failed
move /y "%TEMP_OUT%" "%OUTPUT%" >nul
if errorlevel 1 exit /b 2
echo Created "%OUTPUT%"
exit /b 0
:failed
echo Source: "%INPUT%" 1>&2
if exist "%TEMP_OUT%" del /q "%TEMP_OUT%" >nul 2>&1
exit /b %RC%
:usage
echo Usage: key.cmd source.key output.exe_or_dll_or_obj 1>&2
exit /b 2
:native
if not exist "%~dp0bin\key.exe" (
  echo Native KEY tools are missing: bin\key.exe 1>&2
  exit /b 2
)
"%~dp0bin\key.exe" %*
exit /b %ERRORLEVEL%
