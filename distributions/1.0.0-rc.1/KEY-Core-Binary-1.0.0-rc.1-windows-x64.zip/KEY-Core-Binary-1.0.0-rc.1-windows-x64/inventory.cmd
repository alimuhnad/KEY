@echo off
setlocal DisableDelayedExpansion
if not exist "%~dp0bin\KEY-InventoryApp.exe" (
  echo Inventory executable is missing. Extract the complete KEY binary package. 1>&2
  exit /b 1
)
"%~dp0bin\KEY-InventoryApp.exe"
exit /b %ERRORLEVEL%
